/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGraphicsView *graphicsView;
    QWidget *widget;
    QWidget *gridLayoutWidget;
    QGridLayout *layoutOpcionesMovimiento;
    QLabel *labelBateria;
    QLabel *labelRecursos;
    QPushButton *btnMotorPlasma;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1316, 476);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        centralwidget->setEnabled(true);
        graphicsView = new QGraphicsView(centralwidget);
        graphicsView->setObjectName("graphicsView");
        graphicsView->setGeometry(QRect(0, 0, 921, 411));
        QSizePolicy sizePolicy(QSizePolicy::Policy::Ignored, QSizePolicy::Policy::Ignored);
        sizePolicy.setHorizontalStretch(3);
        sizePolicy.setVerticalStretch(3);
        sizePolicy.setHeightForWidth(graphicsView->sizePolicy().hasHeightForWidth());
        graphicsView->setSizePolicy(sizePolicy);
        graphicsView->setMouseTracking(true);
        widget = new QWidget(centralwidget);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(930, 0, 361, 411));
        gridLayoutWidget = new QWidget(widget);
        gridLayoutWidget->setObjectName("gridLayoutWidget");
        gridLayoutWidget->setGeometry(QRect(0, 10, 361, 331));
        layoutOpcionesMovimiento = new QGridLayout(gridLayoutWidget);
        layoutOpcionesMovimiento->setObjectName("layoutOpcionesMovimiento");
        layoutOpcionesMovimiento->setSizeConstraint(QLayout::SizeConstraint::SetDefaultConstraint);
        layoutOpcionesMovimiento->setContentsMargins(0, 0, 0, 0);
        labelBateria = new QLabel(widget);
        labelBateria->setObjectName("labelBateria");
        labelBateria->setGeometry(QRect(0, 340, 251, 31));
        labelRecursos = new QLabel(widget);
        labelRecursos->setObjectName("labelRecursos");
        labelRecursos->setGeometry(QRect(210, 350, 131, 21));
        btnMotorPlasma = new QPushButton(widget);
        btnMotorPlasma->setObjectName("btnMotorPlasma");
        btnMotorPlasma->setGeometry(QRect(0, 380, 359, 24));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1316, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        labelBateria->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        labelRecursos->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        btnMotorPlasma->setText(QCoreApplication::translate("MainWindow", "Comprar Motor (1000)", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
